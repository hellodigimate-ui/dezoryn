import { Request, Response } from 'express';
import { DemoService } from '../services/demo.service';

export class DemoController {
  static async getAll(req: Request, res: Response): Promise<void> {
    try {
      const activeOnly = req.query.active === 'true';
      const demos = await DemoService.getAll(activeOnly);
      res.status(200).json({
        success: true,
        data: demos,
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to fetch product demos',
      });
    }
  }

  static async getById(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const demo = await DemoService.getById(id);
      if (!demo) {
        res.status(404).json({ success: false, message: 'Product demo not found' });
        return;
      }
      res.status(200).json({
        success: true,
        data: demo,
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to fetch product demo',
      });
    }
  }

  static async create(req: Request, res: Response): Promise<void> {
    try {
      const demo = await DemoService.create(req.body);
      res.status(201).json({
        success: true,
        message: 'Product demo created successfully',
        data: demo,
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to create product demo',
      });
    }
  }

  static async update(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const updated = await DemoService.update(id, req.body);
      res.status(200).json({
        success: true,
        message: 'Product demo updated successfully',
        data: updated,
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to update product demo',
      });
    }
  }

  static async delete(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      await DemoService.delete(id);
      res.status(200).json({
        success: true,
        message: 'Product demo deleted successfully',
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to delete product demo',
      });
    }
  }
}
