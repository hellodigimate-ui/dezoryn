import { Request, Response } from 'express';
import { ContactService } from '../services/contact.service';

export class ContactController {
  static async get(req: Request, res: Response): Promise<void> {
    try {
      const data = await ContactService.get();
      res.status(200).json({
        success: true,
        data,
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to fetch contact settings',
      });
    }
  }

  static async update(req: Request, res: Response): Promise<void> {
    try {
      const updated = await ContactService.update(req.body);
      res.status(200).json({
        success: true,
        message: 'Contact information updated successfully',
        data: updated,
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to update contact information',
      });
    }
  }
}
