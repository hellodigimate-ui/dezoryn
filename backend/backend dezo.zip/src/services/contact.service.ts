import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const db = prisma as any;

export interface ContactSettingsPayload {
  phone?: string;
  email?: string;
  address?: string;
  googleMap?: string;
  socialLinks?: any;
  whatsApp?: string;
  businessHours?: string;
}

const DEFAULT_CONTACT = {
  id: 'default',
  phone: '+91 77778 04850',
  email: 'support@dezoryn.com',
  address: 'Indore, Madhya Pradesh, India',
  googleMap: 'https://maps.google.com/?q=Indore,Madhya+Pradesh,India',
  socialLinks: {
    twitter: 'https://twitter.com',
    linkedin: 'https://linkedin.com',
    github: 'https://github.com',
    facebook: 'https://facebook.com',
    instagram: 'https://instagram.com',
    youtube: 'https://youtube.com',
  },
  whatsApp: '+917777804850',
  businessHours: 'Mon - Fri: 9:00 AM - 6:00 PM IST | Sat - Sun: Closed',
};

async function seedDefaultContactRaw() {
  try {
    await prisma.$executeRawUnsafe(
      `INSERT INTO contact_settings (id, phone, email, address, "googleMap", "socialLinks", "whatsApp", "businessHours", "createdAt", "updatedAt")
       VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7, $8, NOW(), NOW())
       ON CONFLICT (id) DO NOTHING`,
      DEFAULT_CONTACT.id,
      DEFAULT_CONTACT.phone,
      DEFAULT_CONTACT.email,
      DEFAULT_CONTACT.address,
      DEFAULT_CONTACT.googleMap,
      JSON.stringify(DEFAULT_CONTACT.socialLinks),
      DEFAULT_CONTACT.whatsApp,
      DEFAULT_CONTACT.businessHours
    );
  } catch {
    // ignore seed error
  }
}

export class ContactService {
  static async get() {
    try {
      if (db.contactSettings) {
        let settings = await db.contactSettings.findUnique({ where: { id: 'default' } });
        if (!settings) {
          settings = await db.contactSettings.create({ data: DEFAULT_CONTACT });
        }
        return settings;
      }
    } catch {
      // Fall through to raw SQL
    }

    try {
      const rows: any = await prisma.$queryRawUnsafe('SELECT * FROM contact_settings WHERE id = $1', 'default');
      if (rows && rows.length > 0) {
        return rows[0];
      } else {
        await seedDefaultContactRaw();
        const seeded: any = await prisma.$queryRawUnsafe('SELECT * FROM contact_settings WHERE id = $1', 'default');
        return seeded[0] || DEFAULT_CONTACT;
      }
    } catch {
      return DEFAULT_CONTACT;
    }
  }

  static async update(payload: ContactSettingsPayload) {
    const existing = await ContactService.get();

    const updatedData = {
      phone: payload.phone ?? existing.phone ?? DEFAULT_CONTACT.phone,
      email: payload.email ?? existing.email ?? DEFAULT_CONTACT.email,
      address: payload.address ?? existing.address ?? DEFAULT_CONTACT.address,
      googleMap: payload.googleMap ?? existing.googleMap ?? DEFAULT_CONTACT.googleMap,
      socialLinks: payload.socialLinks ?? existing.socialLinks ?? DEFAULT_CONTACT.socialLinks,
      whatsApp: payload.whatsApp ?? existing.whatsApp ?? DEFAULT_CONTACT.whatsApp,
      businessHours: payload.businessHours ?? existing.businessHours ?? DEFAULT_CONTACT.businessHours,
    };

    try {
      if (db.contactSettings) {
        return await db.contactSettings.upsert({
          where: { id: 'default' },
          update: updatedData,
          create: { id: 'default', ...updatedData },
        });
      }
    } catch {
      // Fall through to raw SQL
    }

    try {
      await prisma.$executeRawUnsafe(
        `INSERT INTO contact_settings (id, phone, email, address, "googleMap", "socialLinks", "whatsApp", "businessHours", "createdAt", "updatedAt")
         VALUES ('default', $1, $2, $3, $4, $5::jsonb, $6, $7, NOW(), NOW())
         ON CONFLICT (id) DO UPDATE SET
           phone = EXCLUDED.phone,
           email = EXCLUDED.email,
           address = EXCLUDED.address,
           "googleMap" = EXCLUDED."googleMap",
           "socialLinks" = EXCLUDED."socialLinks",
           "whatsApp" = EXCLUDED."whatsApp",
           "businessHours" = EXCLUDED."businessHours",
           "updatedAt" = NOW()`,
        updatedData.phone,
        updatedData.email,
        updatedData.address,
        updatedData.googleMap,
        JSON.stringify(updatedData.socialLinks),
        updatedData.whatsApp,
        updatedData.businessHours
      );

      return { id: 'default', ...updatedData };
    } catch (err) {
      console.error('Error updating contact settings:', err);
      throw err;
    }
  }
}
