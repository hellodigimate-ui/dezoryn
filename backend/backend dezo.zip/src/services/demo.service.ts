import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const db = prisma as any;

export interface ProductDemoPayload {
  title: string;
  description?: string;
  videoUrl: string;
  thumbnailUrl?: string;
  category?: string;
  order?: number;
  isActive?: boolean;
}

const DEFAULT_DEMOS = [
  {
    id: 'demo-1',
    title: 'SchoolyCore Demo',
    description: 'Complete Education Management & Student Lifecycle Suite.',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?q=80&w=800&auto=format&fit=crop',
    category: 'Education',
    order: 1,
    isActive: true,
  },
  {
    id: 'demo-2',
    title: 'Hospital Management Demo',
    description: 'Next-Gen EHR, OPD Billing & Patient Workflow Platform.',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=800&auto=format&fit=crop',
    category: 'Healthcare',
    order: 2,
    isActive: true,
  },
  {
    id: 'demo-3',
    title: 'HRMS Demo',
    description: 'AI Payroll, Attendance Tracking & Employee Performance Hub.',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=800&auto=format&fit=crop',
    category: 'Enterprise',
    order: 3,
    isActive: true,
  },
  {
    id: 'demo-4',
    title: 'InventoryPro Demo',
    description: 'Real-Time Supply Chain & Multi-Warehouse Automation.',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?q=80&w=800&auto=format&fit=crop',
    category: 'Logistics',
    order: 4,
    isActive: true,
  },
];

let hasAttemptedDemoInitialSeed = false;

async function seedInitialDemosRaw() {
  for (const item of DEFAULT_DEMOS) {
    try {
      await prisma.$executeRawUnsafe(
        `INSERT INTO product_demos (id, title, description, "videoUrl", "thumbnailUrl", category, "order", "isActive", "createdAt", "updatedAt")
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW())
         ON CONFLICT (id) DO NOTHING`,
        item.id, item.title, item.description, item.videoUrl,
        item.thumbnailUrl, item.category, item.order, item.isActive
      );
    } catch {
      // ignore
    }
  }
}

export class DemoService {
  static async getAll(activeOnly: boolean = false) {
    if (!hasAttemptedDemoInitialSeed) {
      hasAttemptedDemoInitialSeed = true;
      try {
        const countRes: any = await prisma.$queryRawUnsafe('SELECT COUNT(*)::int as count FROM product_demos');
        if (countRes[0]?.count === 0) {
          await seedInitialDemosRaw();
        }
      } catch {
        // ignore
      }
    }

    try {
      if (db.productDemo) {
        const where = activeOnly ? { isActive: true } : {};
        return await db.productDemo.findMany({
          where,
          orderBy: { order: 'asc' },
        });
      }
    } catch {
      // Fall through to raw SQL
    }

    try {
      let sql = 'SELECT * FROM product_demos';
      if (activeOnly) {
        sql += ' WHERE "isActive" = true';
      }
      sql += ' ORDER BY "order" ASC';

      return await prisma.$queryRawUnsafe(sql);
    } catch {
      return DEFAULT_DEMOS;
    }
  }

  static async getById(id: string) {
    try {
      if (db.productDemo) {
        return await db.productDemo.findUnique({ where: { id } });
      }
    } catch {
      // Fall through
    }

    const rows: any = await prisma.$queryRawUnsafe('SELECT * FROM product_demos WHERE id = $1', id);
    return rows ? rows[0] : null;
  }

  static async create(payload: ProductDemoPayload) {
    const data = {
      title: payload.title,
      description: payload.description || '',
      videoUrl: payload.videoUrl,
      thumbnailUrl: payload.thumbnailUrl || '',
      category: payload.category || 'General',
      order: payload.order ?? 0,
      isActive: payload.isActive ?? true,
    };

    try {
      if (db.productDemo) {
        return await db.productDemo.create({ data });
      }
    } catch {
      // Fall through to raw SQL
    }

    const id = `demo_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    await prisma.$executeRawUnsafe(
      `INSERT INTO product_demos (id, title, description, "videoUrl", "thumbnailUrl", category, "order", "isActive", "createdAt", "updatedAt")
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW())`,
      id, data.title, data.description, data.videoUrl,
      data.thumbnailUrl, data.category, data.order, data.isActive
    );

    const rows: any = await prisma.$queryRawUnsafe('SELECT * FROM product_demos WHERE id = $1', id);
    return rows[0] || { id, ...data };
  }

  static async update(id: string, payload: Partial<ProductDemoPayload>) {
    try {
      if (db.productDemo) {
        return await db.productDemo.update({
          where: { id },
          data: payload,
        });
      }
    } catch {
      // Fall through to raw SQL
    }

    const existing = await DemoService.getById(id);
    if (!existing) throw new Error('Product demo not found');

    const updatedData = {
      title: payload.title ?? existing.title,
      description: payload.description ?? existing.description,
      videoUrl: payload.videoUrl ?? existing.videoUrl,
      thumbnailUrl: payload.thumbnailUrl ?? existing.thumbnailUrl,
      category: payload.category ?? existing.category,
      order: payload.order ?? existing.order,
      isActive: payload.isActive ?? existing.isActive,
    };

    await prisma.$executeRawUnsafe(
      `UPDATE product_demos SET
        title = $1, description = $2, "videoUrl" = $3, "thumbnailUrl" = $4,
        category = $5, "order" = $6, "isActive" = $7, "updatedAt" = NOW()
       WHERE id = $8`,
      updatedData.title, updatedData.description, updatedData.videoUrl,
      updatedData.thumbnailUrl, updatedData.category, updatedData.order,
      updatedData.isActive, id
    );

    const rows: any = await prisma.$queryRawUnsafe('SELECT * FROM product_demos WHERE id = $1', id);
    return rows[0];
  }

  static async delete(id: string) {
    try {
      if (db.productDemo) {
        await db.productDemo.delete({ where: { id } });
        return { success: true };
      }
    } catch {
      // Fall through
    }

    await prisma.$executeRawUnsafe('DELETE FROM product_demos WHERE id = $1', id);
    return { success: true };
  }
}
