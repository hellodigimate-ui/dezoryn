import { Router } from 'express';
import { ContactController } from '../controllers/contact.controller';

const router = Router();

router.get('/', ContactController.get);
router.put('/', ContactController.update);

export default router;
