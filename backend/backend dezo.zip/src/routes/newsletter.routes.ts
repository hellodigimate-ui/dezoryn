import { Router, Request, Response } from 'express';

const router = Router();

// In-memory subscriber store (no DB migration needed)
const subscribers = new Set<string>();

// POST /api/v1/newsletter/subscribe
router.post('/subscribe', (req: Request, res: Response) => {
  const { email } = req.body as { email?: string };

  if (!email || typeof email !== 'string') {
    return res.status(400).json({ success: false, message: 'Email is required.' });
  }

  const trimmed = email.trim().toLowerCase();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(trimmed)) {
    return res.status(400).json({ success: false, message: 'Please provide a valid email address.' });
  }

  if (subscribers.has(trimmed)) {
    return res.status(200).json({ success: true, message: 'You are already subscribed! We\'ll keep you updated.' });
  }

  subscribers.add(trimmed);
  console.log(`[Newsletter] New subscriber: ${trimmed} (total: ${subscribers.size})`);

  return res.status(201).json({
    success: true,
    message: 'Successfully subscribed! Welcome to the Dezoryn community 🎉',
  });
});

// GET /api/v1/newsletter/subscribers (admin only — no auth middleware for now)
router.get('/subscribers', (_req: Request, res: Response) => {
  return res.status(200).json({
    success: true,
    data: { count: subscribers.size, subscribers: Array.from(subscribers) },
  });
});

export default router;
